//TextLab01 - This is a comment. Java will not run this comment.
/*This is a longer comment. Java will still not run this commment. This comment will end when i put */

public class AKansupada01 {
    public static void main(String args[]) {
      System.out.println();
      System.out.println();
      System.out.print("In computer programming ");
      System.out.println("you have to type everything exactly.");
      System.out.println("\nThe \\ key does some weird stuff.");
      System.out.println();
      System.out.print("There is a big");
      System.out.print(" difference ");
      System.out.println("between:\n\"Let's eat, Grandma\" ");
      System.out.println("\tand");
      System.out.println("\"Let's eat Grandma\"");
      System.out.println();
      System.out.println("      A        H     H  K   K");
      System.out.println("     A A       H     H  K  K");
      System.out.println("    A   A      H     H  K K");
      System.out.println("   AAAAAAA     HHHHHHH  KK");
      System.out.println("  A       A    H     H  K K");
      System.out.println(" A         A   H     H  K  K");
      System.out.println("A           A  H     H  K   K");
      
      

      
    }
}