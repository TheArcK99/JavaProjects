Welcome and thanks for using Contract P.I, an efficient way to scan contract or text for predatory language or 
other specific words/phrases. Here is an in-depth guide to the usage of this software. Enjoy!

Main Manu: 
Once openeing the application you are presented with the main menu. On this menu there are 3 main buttons in the center
of the screen along with two in the bottom corners. Moving through the interface is quite straighfroward, simple click
on the buttons present throughout it. Here is an overview of each of the buttons and their function. 

Settings: 
Click on the round icon in the bottom-left to go to the settings menu. Here you can change the user interface and toggle
between differtn colors for the background, accents, and text. 

Exit:
On the bottom right is the exit button that closes the application. On other pages this will be the back arrow to take
you back to the main menu. 

About: 
This sections breiefly explains the inspiration behind this application and the issue that it solves and the value
which it provides.

Wiki: 
This section provides a cut-down version of this file for reference during use of the applicastion, and omits a few key
details. 

Scan:
This is where the real functionality of the app lies. Upon clicking the button you will be taken to a seperate menu
with a few gentle reminders about the functionality and an upload button. The app works by pulling a list of key words/phrases
to scan for from .txt file. In order to customize the words scanned for, edit the words.txt file in the the data folder under
the classess folder. Edit the coucment with what words you wantto scan for, just make sure there is one word/phrase per line
and that there are no additonal lines in the doucment(this may cause the program to break). Back to the scan menu, there is
a central upload button. Once you click tat, it will take you to menu where you can select the file you wish to scan.
Currently, the application only supports .txt files, so only upload those kind. In the case you don't, a erroe message will spit
out, so just restart the application. The finished, scanned file, will output as <documentName>-output.txt in the same 
folder from which you uploaded the initial file. 

Thats the basics of using Contract P.I! Enjoy!
